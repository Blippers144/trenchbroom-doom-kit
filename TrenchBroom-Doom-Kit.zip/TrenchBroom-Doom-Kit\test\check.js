// Structural checks on a converted WAD: every sector outline is closed, no zero-length or duplicate lines,
// textures exist in DOOM2.WAD, things sit inside sectors. Usage: node test/check.js <file.wad>
'use strict';
const fs = require('fs'), path = require('path');
const { readWad, loadGraphics } = require('../lib/wad');
const file = process.argv[2], w = readWad(fs.readFileSync(file)), text = w.data(w.find('TEXTMAP')).toString();
const blocks = []; const re = /(\w+)\s*\{([^}]*)\}/g; let m;
while ((m = re.exec(text))) { const o = { kind: m[1] }; for (const kv of m[2].split(';')) { const mm = kv.match(/^\s*(\w+)\s*=\s*(.+?)\s*$/s); if (mm) o[mm[1]] = mm[2].startsWith('"') ? JSON.parse(mm[2]) : mm[2] === 'true' ? true : +mm[2]; } blocks.push(o); }
const V = blocks.filter(b => b.kind === 'vertex'), L = blocks.filter(b => b.kind === 'linedef'), S = blocks.filter(b => b.kind === 'sidedef'), SEC = blocks.filter(b => b.kind === 'sector'), T = blocks.filter(b => b.kind === 'thing');
const errs = [], cfg = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'config.json'), 'utf8')), G = loadGraphics(fs.readFileSync(cfg.iwad));
// closed outlines: for each sector, edges with the sector on their right must form cycles (in-degree == out-degree)
const deg = SEC.map(() => new Map());
const seen = new Set();
for (const l of L) {
  const a = V[l.v1], b = V[l.v2];
  if (!a || !b) { errs.push('line with a missing vertex'); continue; }
  if (Math.hypot(a.x - b.x, a.y - b.y) < 0.01) errs.push('zero-length line');
  const k = Math.min(l.v1, l.v2) + ',' + Math.max(l.v1, l.v2); if (seen.has(k)) errs.push(`duplicate line ${k}`); seen.add(k);
  const add = (side, from, to) => { const s = S[side]; if (!s) return; const d = deg[s.sector]; d.set(from, (d.get(from) || 0) + 1); d.set(to, (d.get(to) || 0) - 1); };
  add(l.sidefront, l.v1, l.v2); if (l.sideback !== undefined) add(l.sideback, l.v2, l.v1);
  if (l.sideback !== undefined && S[l.sidefront].sector === S[l.sideback].sector) errs.push('line with the same sector on both sides');
}
deg.forEach((d, i) => { for (const [v, n] of d) if (n) { errs.push(`sector ${i} is not closed at vertex ${v} (${V[v].x}, ${V[v].y})`); break; } });
const has = n => n === '-' || G.textures.has(n) || G.flats.has(n);
for (const s of S) for (const k of ['texturetop', 'texturemiddle', 'texturebottom']) if (s[k] && !has(s[k])) errs.push('unknown texture ' + s[k]);
for (const s of SEC) for (const k of ['texturefloor', 'textureceiling']) if (!has(s[k])) errs.push('unknown flat ' + s[k]);
for (const s of SEC) if (s.heightceiling < s.heightfloor) errs.push(`sector with ceiling below floor (${s.heightfloor} / ${s.heightceiling})`);
console.log(`${path.basename(file)}: ${SEC.length} sectors, ${L.length} lines, ${T.length} things, ${V.length} vertices`);
console.log(errs.length ? [...new Set(errs)].slice(0, 30).map(e => '  ERROR ' + e).join('\n') : '  OK: every sector is closed, textures exist');
process.exitCode = errs.length ? 1 : 0;
