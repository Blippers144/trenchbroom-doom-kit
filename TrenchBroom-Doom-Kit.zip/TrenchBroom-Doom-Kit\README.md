# TrenchBroom Doom Kit

Build Doom levels in **TrenchBroom** with brushes, the way Quake maps are made, then play them in **UZDoom** or **GZDoom** with one click. The kit adds Doom as a game in TrenchBroom, with the DOOM II textures and every Doom monster, weapon, item, key and decoration shown with its real sprite. It also converts your map into a Doom map WAD.

## What you need
- **Windows**
- [TrenchBroom](https://github.com/TrenchBroom/TrenchBroom/releases) (free). Open it once before installing the kit.
- [UZDoom](https://github.com/UZDoom/UZDoom/releases) or [GZDoom](https://zdoom.org/downloads) (free)
- **Your own DOOM2.WAD**, from Doom II on Steam or GOG for example. The kit reads the textures and sprites from it; none are included. Freedoom's `freedoom2.wad` should also work, but this hasn't been tested.
- [Node.js](https://nodejs.org) (free, the LTS version). It runs the installer and the converter.

## Install
1. Unzip the kit somewhere permanent, for example `Documents\DoomKit`. TrenchBroom will read the Doom textures from this folder, so don't delete it.
2. Close TrenchBroom.
3. Double-click **`Install.cmd`**. It finds UZDoom/GZDoom and DOOM2.WAD by itself; if it can't, it asks you to paste their paths.

Run `Install.cmd` again whenever you move the kit, UZDoom or your WAD.

## Making a level
1. Open TrenchBroom → **New map** → choose **Doom**. You start in a small room with a player start.
2. Build with brushes. Textures are in the Materials browser: `walls/` holds wall textures and `flats/` holds floors and ceilings. Things are in the Entity browser, grouped as `monster_`, `weapon_`, `ammo_`, `health_`, `armor_`, `key_`, `powerup_`, `decor_`, `info_player_start` and `light`.
3. **Run → Compile Map…** → **Build WAD and play in UZDoom** → **Compile**. The WAD is saved in the kit's `build` folder, named after your map, and UZDoom starts in your level.

From a command prompt instead: `node map2wad.js mylevel.map mylevel.wad --play`.

## How brushes become Doom
A Doom map is a floor plan: every area has one floor height and one ceiling height. The converter looks down on your level from above and cuts it into areas along every brush edge. For each area it looks straight up:
- the top of the lowest brush is the **floor**, and that face's texture becomes the floor texture;
- the bottom of the highest brush is the **ceiling**, and that face's texture becomes the ceiling texture;
- brushes in between become **3D floors** in UZDoom, giving you bridges, ledges and platforms;
- the side faces of brushes give the **wall textures**, keeping your TrenchBroom offsets.

In practice:
- **Rooms:** a room needs a floor brush under it and a ceiling brush over it. Walls are brushes that go from floor to ceiling.
- **Sky:** put `flats/F_SKY1` on the bottom of a ceiling brush.
- **Slopes:** a sloped top or bottom face (a wedge, a ramp, a clipped brush) becomes a sloped floor or ceiling.
- **Pillars, crates, steps, round columns and rotated shapes:** anything with straight up-and-down sides converts exactly. Doom can't draw walls that lean. A brush with slanted sides still works, but its slant becomes part of the floor or ceiling around it.
- **Lighting:**
  - Set `sectorlight` on the world (default 192).
  - To change one area, turn a brush into a `doom_sector` entity. It's see-through and not solid. Set its light, effect (flicker, strobe, glow, damaging floor), colour, fog or secret flag.
  - `light` entities become dynamic lights.
- **Monsters and items:** `angle` sets which way they face. Spawnflags set Ambush, skill levels, multiplayer-only and Friendly.
- **Level settings:** the map slot (MAP01–MAP32), level name, next map and sky are properties of the world (worldspawn).

## Not done yet
Doors, lifts, teleporters, switches and exits.

## Files
- `Install.cmd` / `setup.js`: install the Doom game into TrenchBroom (`%APPDATA%\TrenchBroom\games\Doom`), extract textures and sprites from your WAD into `gamedata\`, and add the compile profiles.
- `map2wad.js`: the converter.
  - `lib/mapfile.js` handles .map parsing and brush geometry.
  - `lib/arrange.js` does the top-down cutting.
  - `lib/wad.js` reads and writes WADs.
  - `lib/things.js` is the Doom thing list.
- `test/make-test-map.js` builds a test level that uses every feature. `test/check.js` checks a converted WAD for open sectors and missing textures.

## License
MIT. See `LICENSE`. DOOM and DOOM II are trademarks of id Software. This kit contains no id Software files; it reads them from the WAD you own.
