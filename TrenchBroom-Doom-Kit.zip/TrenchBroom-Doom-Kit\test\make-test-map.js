// Writes test/test.map (Valve format) using the features the converter must handle.
'use strict';
const fs = require('fs'), path = require('path');
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
// face from 3 points + outward direction; texture axes picked like TrenchBroom does for new brushes
function face(pts, out, tex) {
  let [p1, p2, p3] = pts; if (dot(cross(sub(p3, p1), sub(p2, p1)), out) < 0) [p2, p3] = [p3, p2];
  const n = out, az = Math.abs(n[2]);
  const U = az > 0.7 ? [1, 0, 0] : Math.abs(n[0]) > Math.abs(n[1]) ? [0, Math.sign(n[0]) || 1, 0] : [-(Math.sign(n[1]) || 1), 0, 0];
  const V = az > 0.7 ? [0, -1, 0] : [0, 0, -1];
  return `( ${p1.join(' ')} ) ( ${p2.join(' ')} ) ( ${p3.join(' ')} ) ${tex} [ ${U.join(' ')} 0 ] [ ${V.join(' ')} 0 ] 0 1 1`;
}
function box(x0, y0, z0, x1, y1, z1, t = {}) {
  const W = t.wall || 'walls/STARTAN2', F = t.top || 'flats/FLOOR4_8', C = t.bottom || 'flats/CEIL3_5';
  return ['{',
    face([[x0, y0, z1], [x1, y0, z1], [x0, y1, z1]], [0, 0, 1], F), face([[x0, y0, z0], [x1, y0, z0], [x0, y1, z0]], [0, 0, -1], C),
    face([[x1, y0, z0], [x1, y1, z0], [x1, y0, z1]], [1, 0, 0], W), face([[x0, y0, z0], [x0, y1, z0], [x0, y0, z1]], [-1, 0, 0], W),
    face([[x0, y1, z0], [x1, y1, z0], [x0, y1, z1]], [0, 1, 0], W), face([[x0, y0, z0], [x1, y0, z0], [x0, y0, z1]], [0, -1, 0], W), '}'].join('\n');
}
// ramp rising along +x from (x0, z0) to (x1, z1)
function ramp(x0, y0, x1, y1, zb, z0, z1, t = {}) {
  const W = t.wall || 'walls/BROWN1', F = t.top || 'flats/FLAT5_4';
  const up = [-(z1 - z0), 0, x1 - x0];
  return ['{',
    face([[x0, y0, z0], [x1, y0, z1], [x0, y1, z0]], up, F), face([[x0, y0, zb], [x1, y0, zb], [x0, y1, zb]], [0, 0, -1], F),
    face([[x1, y0, zb], [x1, y1, zb], [x1, y0, z1]], [1, 0, 0], W), (z0 > zb ? face([[x0, y0, zb], [x0, y1, zb], [x0, y0, z0]], [-1, 0, 0], W) : ''),
    face([[x0, y1, zb], [x1, y1, zb], [x1, y1, z1]], [0, 1, 0], W), face([[x0, y0, zb], [x1, y0, zb], [x1, y0, z1]], [0, -1, 0], W), "}"].filter(Boolean).join('\n');
}
// convex prism from a counter-clockwise polygon; top can be sloped: top(x, y) -> z (linear)
function prism(poly, zb, top, t = {}) {
  const W = t.wall || 'walls/GRAY1', F = t.top || 'flats/FLAT1', n = poly.length, tz = typeof top === 'number' ? () => top : top;
  const P = poly.map(([x, y]) => [x, y, tz(x, y)]), [a, b, c] = [P[0], P[1], P[2]];
  let up = cross(sub(b, a), sub(c, a)); if (up[2] < 0) up = up.map(v => -v);
  const f = [face([a, b, c], up, F), face([[poly[0][0], poly[0][1], zb], [poly[1][0], poly[1][1], zb], [poly[2][0], poly[2][1], zb]], [0, 0, -1], F)];
  for (let i = 0; i < n; i++) { const [x1, y1] = poly[i], [x2, y2] = poly[(i + 1) % n]; f.push(face([[x1, y1, zb], [x2, y2, zb], [x1, y1, zb + 1]], [y2 - y1, -(x2 - x1), 0], W)); }
  return ['{', ...f, '}'].join(String.fromCharCode(10));
}
const B = [];
const t = 16, X0 = -512, Y0 = -512, X1 = 512, Y1 = 512, F = 0, C = 256;
B.push(box(X0 - t, Y0 - t, F - t, X1 + t, Y1 + t, F, { top: 'flats/FLOOR4_8' }));
B.push(box(X0 - t, Y0 - t, C, 0, Y1 + t, C + t, { bottom: 'flats/CEIL3_5' }));          // west half: normal ceiling
B.push(box(0, Y0 - t, C + 128, X1 + t, Y1 + t, C + 128 + t, { bottom: 'flats/F_SKY1' })); // east half: open sky, higher
B.push(box(X0 - t, Y0 - t, F, X0, Y1 + t, C + 128), box(X1, Y0 - t, F, X1 + t, Y1 + t, C + 128));
B.push(box(X0, Y0 - t, F, X1, Y0, C + 128), box(X0, Y1, F, X1, Y1 + t, C + 128));
B.push(box(0, Y0, C, t, Y1, C + 128, { wall: 'walls/BRICK7' }));                          // wall above the step between ceilings... (sky edge)
// stairs
for (let i = 0; i < 4; i++) B.push(box(128 + i * 64, 256, F, 192 + i * 64, 512, F + 16 * (i + 1), { wall: 'walls/STEP1', top: 'flats/FLAT5_1' }));
// pillar
B.push(box(-96, -96, F, -32, -32, C, { wall: 'walls/SUPPORT2' }));
// ramp
B.push(ramp(128, -400, 384, -272, F, F, 64));
// bridge (3D floor)
B.push(box(-400, -512, 96, -320, 512, 112, { wall: 'walls/METAL', top: 'flats/CEIL5_1', bottom: 'flats/CEIL5_1' }));
// second room east, through a doorway in the east wall (x 512..528, y -64..64)
B.splice(B.indexOf(box(X1, Y0 - t, F, X1 + t, Y1 + t, C + 128)), 1);
B.push(box(X1, Y0 - t, F, X1 + t, -64, C + 128), box(X1, 64, F, X1 + t, Y1 + t, C + 128), box(X1, -64, 128, X1 + t, 64, C + 128));
B.push(box(X1 + t, -400, F - 32 - t, 1200, 400, F - 32, { top: 'flats/FLOOR0_1' }), box(X1 + t, -400, 200, 1200, 400, 200 + t, { bottom: 'flats/CEIL1_1' }));
B.push(box(X1 + t, -400 - t, F - 32, 1200, -400, 200, { wall: 'walls/BROWN96' }), box(X1 + t, 400, F - 32, 1200, 400 + t, 200, { wall: 'walls/BROWN96' }), box(1200, -400 - t, F - 32, 1200 + t, 400 + t, 200, { wall: 'walls/BROWN96' }));
B.push(box(X1, -64, F - 32, X1 + t, 64, F, { top: 'flats/FLOOR0_1', wall: 'walls/BROWN96' })); // floor under the doorway, stepping down
// round pillar (12 sides), 45-degree pillar, overlapping crates, diagonal ramp
B.push(prism(Array.from({ length: 12 }, (_, i) => [800 + 64 * Math.cos(i * Math.PI / 6), -200 + 64 * Math.sin(i * Math.PI / 6)].map(Math.round)), F - 32, 200, { wall: 'walls/MARBLE1' }));
B.push(prism([[1000, 200], [1060, 260], [1000, 320], [940, 260]], F - 32, 200, { wall: 'walls/SUPPORT3' }));
B.push(box(700, 150, F - 32, 800, 250, 32, { wall: 'walls/CRATE1', top: 'flats/CRATOP2' }), box(760, 200, F - 32, 840, 300, 64, { wall: 'walls/CRATE2', top: 'flats/CRATOP1' }));
B.push(prism([[900, -380], [1180, -380], [1180, -100]], F - 32, (x, y) => -32 + (x - 900) * 0.15 + (y + 380) * 0.05, { wall: 'walls/BROWN1', top: 'flats/FLAT5_4' }));
const world = `{\n"classname" "worldspawn"\n"mapversion" "220"\n"message" "Kit test"\n"sectorlight" "192"\n${B.join('\n')}\n}\n`;
const ents = [
  ['info_player_start', process.env.START ? process.env.START.split(',')[0] : '-200 -300 0', process.env.START ? +process.env.START.split(',')[1] : 90], ['monster_imp', '300 400 64', 270], ['monster_shotgun_guy', '250 -330 32', 180], ['weapon_shotgun', '-200 -200 0', 0],
  ['decor_tall_red_torch', '-450 450 0', 0],
];
let es = ents.map(([c, o, a]) => `{\n"classname" "${c}"\n"origin" "${o}"\n"angle" "${a}"\n}`).join('\n');
es += `\n{\n"classname" "light"\n"origin" "-200 0 128"\n"light" "300"\n"_color" "1 0.5 0.3"\n}`;
es += `\n{\n"classname" "doom_sector"\n"light" "112"\n"special" "65"\n${box(-512, 200, -32, -432, 512, 300)}\n}`;
fs.writeFileSync(path.join(__dirname, 'test.map'), '// Game: Doom\n// Format: Valve\n' + world + es + '\n');
console.log('wrote test/test.map');
