#!/usr/bin/env node
// Installs "Doom" as a game in TrenchBroom:
//  - extracts DOOM2.WAD textures, flats and sprites to gamedata/ (TrenchBroom's game path)
//  - writes Doom.fgd (every Doom thing, shown with its sprite), GameConfig.cfg and a starter map
//  - adds compile profiles that convert the map to a WAD and start UZDoom
// Usage: node setup.js [--uzdoom <uzdoom.exe>] [--iwad <DOOM2.WAD>]   (finds both by itself when left out)
'use strict';
const fs = require('fs'), path = require('path'), os = require('os');
const { loadGraphics, png } = require('./lib/wad');
const THINGS = require('./lib/things');

const KIT = __dirname;
const arg = k => { const i = process.argv.indexOf(k); return i > 0 ? process.argv[i + 1] : null; };
const isFile = p => { try { return !!p && fs.statSync(p).isFile(); } catch (e) { return false; } };
let prev = {}; try { prev = JSON.parse(fs.readFileSync(path.join(KIT, 'config.json'), 'utf8')); } catch (e) { }
// Look for UZDoom/GZDoom and an IWAD next to the kit, in the usual folders and in Steam (a few folders deep).
function search() {
  const home = os.homedir(), pf = process.env.ProgramFiles || 'C:\\Program Files', pf86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
  const roots = [path.dirname(KIT), path.join(home, 'Desktop'), path.join(home, 'OneDrive', 'Desktop'), path.join(home, 'Documents'), path.join(home, 'OneDrive', 'Documents'),
    path.join(home, 'Downloads'), path.join(home, 'Games'), 'C:\\Games', 'D:\\Games', path.join(pf, 'UZDoom'), path.join(pf, 'GZDoom'), path.join(pf86, 'Steam', 'steamapps', 'common')];
  const engines = ['uzdoom.exe', 'gzdoom.exe'], iwads = ['doom2.wad', 'freedoom2.wad'];
  let engine = '', iwad = '';
  const scan = (dir, depth) => {
    if (engine && iwad) return; let ents; try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
    for (const e of ents) if (e.isFile()) { const n = e.name.toLowerCase(); if (!engine && engines.includes(n)) engine = path.join(dir, e.name); if (!iwad && iwads.includes(n)) iwad = path.join(dir, e.name); }
    if (depth > 0) for (const e of ents) if (e.isDirectory() && !/^(node_modules|\.|\$|windows|appdata)/i.test(e.name)) scan(path.join(dir, e.name), depth - 1);
  };
  for (const r of roots) scan(r, 3);
  return { engine, iwad };
}
let uzdoom = arg('--uzdoom') || (isFile(prev.uzdoom) ? prev.uzdoom : ''), iwad = arg('--iwad') || (isFile(prev.iwad) ? prev.iwad : '');
if (!uzdoom || !iwad) { console.log('Looking for UZDoom and DOOM2.WAD...'); const f = search(); uzdoom = uzdoom || f.engine; iwad = iwad || f.iwad; }
if (!isFile(uzdoom) || !isFile(iwad)) {
  if (!isFile(uzdoom)) console.log('NOT FOUND: uzdoom.exe (or gzdoom.exe)'); else console.log('UZDoom: ' + uzdoom);
  if (!isFile(iwad)) console.log('NOT FOUND: DOOM2.WAD'); else console.log('IWAD: ' + iwad);
  process.exit(2); // Install.cmd asks for the missing paths and runs setup again
}
console.log('UZDoom: ' + uzdoom); console.log('IWAD:   ' + iwad);
const userData = path.join(process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'), 'TrenchBroom');
const gameDir = path.join(userData, 'games', 'Doom'), gamePath = path.join(KIT, 'gamedata'), data = path.join(gamePath, 'doom');
const fwd = p => p.replace(/\\/g, '/');
for (const d of [gameDir, path.join(data, 'textures', 'walls'), path.join(data, 'textures', 'flats'), path.join(data, 'sprites')]) fs.mkdirSync(d, { recursive: true });

// 1. textures
const G = loadGraphics(fs.readFileSync(iwad));
const safe = n => n.replace(/\\/g, '^');
let nw = 0, nf = 0;
for (const name of G.textures.keys()) { if (name === 'AASHITTY' || name === 'AASTINKY') continue; const t = G.wall(name); if (t) { fs.writeFileSync(path.join(data, 'textures', 'walls', safe(name) + '.png'), png(t.w, t.h, t.rgba)); nw++; } }
for (const name of G.flats.keys()) { const t = G.flat(name); if (t) { fs.writeFileSync(path.join(data, 'textures', 'flats', safe(name) + '.png'), png(64, 64, t.rgba)); nf++; } }
console.log(`textures: ${nw} walls, ${nf} flats`);

// 2. sprites as small crossed-quad models so TrenchBroom shows the real monster/item
let ns = 0;
function spriteModel(cls, spr) {
  const s = spr && G.sprite(spr); if (!s) return false;
  fs.writeFileSync(path.join(data, 'sprites', cls + '.png'), png(s.w, s.h, s.rgba));
  const l = -s.left, r = s.w - s.left, t = s.top, b = s.top - s.h;
  const v = [[l, 0, b], [r, 0, b], [r, 0, t], [l, 0, t], [0, -l, b], [0, -r, b], [0, -r, t], [0, -l, t]];
  fs.writeFileSync(path.join(data, 'sprites', cls + '.mtl'), `newmtl spr\nKd 1 1 1\nmap_Kd ${cls}.png\n`);
  fs.writeFileSync(path.join(data, 'sprites', cls + '.obj'), `mtllib ${cls}.mtl\n${v.map(p => `v ${p[0]} ${p[2]} ${-p[1]}`).join('\n')}\nvt 0 0\nvt 1 0\nvt 1 1\nvt 0 1\nusemtl spr\nf 1/1 2/2 3/3 4/4\nf 4/4 3/3 2/2 1/1\nf 5/1 6/2 7/3 8/4\nf 8/4 7/3 6/2 5/1\n`);
  ns++; return true;
}

// 3. entity definitions
const colour = c => c.startsWith('monster') ? '220 40 40' : c.startsWith('weapon') ? '255 160 0' : c.startsWith('ammo') ? '200 200 60' : c.startsWith('health') || c.startsWith('armor') ? '60 160 255' : c.startsWith('key') ? '255 0 255' : c.startsWith('powerup') ? '60 220 220' : c.startsWith('info') ? '60 255 60' : '160 160 160';
const sectorFx = [[0, 'Normal'], [65, 'Light flickers randomly'], [66, 'Light strobes fast'], [67, 'Light strobes slow'], [72, 'Light glows'], [81, 'Light flickers like fire'], [76, 'Synchronised strobe, slow'], [77, 'Synchronised strobe, fast'], [71, 'Damage 5% (slime)'], [69, 'Damage 10% (nukage)'], [80, 'Damage 20% (lava)'], [68, 'Damage 20% + strobe'], [74, 'Door closes after 30 s'], [78, 'Door opens after 5 min']];
let fgd = `// Doom / Doom II for TrenchBroom (Modern DOOM kit). Brushes become Doom sectors when you run map2wad.

@SolidClass = worldspawn : "World" [
  message(string) : "Level name" : ""
  mapname(string) : "Map slot (MAP01-MAP32)" : "MAP01"
  nextmap(string) : "Next map" : "MAP02"
  sky(choices) : "Sky" : "SKY1" = [ "SKY1" : "City (SKY1)" "SKY2" : "Ruins (SKY2)" "SKY3" : "Hell (SKY3)" ]
  sectorlight(integer) : "Light level of every area, 0-255 (use doom_sector to change one area)" : 192
]
@SolidClass = func_group : "Group of brushes (solid, like the world)" []
@SolidClass = func_detail : "Detail brushes (solid, like the world)" []
@SolidClass color(255 200 0) = doom_sector : "Sector properties: a see-through volume. Areas inside it get these settings." [
  light(integer) : "Light level 0-255" : 192
  special(choices) : "Effect" : 0 = [ ${sectorFx.map(([v, n]) => `${v} : "${n}"`).join(' ')} ]
  color(string) : "Light colour (hex, e.g. ff8080)" : ""
  fade(string) : "Fog colour (hex)" : ""
  secret(choices) : "Secret area" : 0 = [ 0 : "No" 1 : "Yes" ]
  tag(integer) : "Sector tag" : 0
]
@BaseClass = Appear [
  angle(integer) : "Facing angle (0 = east, 90 = north)" : 0
  tid(integer) : "Thing ID (for scripts)" : 0
  spawnflags(flags) = [ 1 : "Ambush (deaf)" : 0  2 : "Not on easy" : 0  4 : "Not on medium" : 0  8 : "Not on hard" : 0  16 : "Not in single player" : 0  32 : "Friendly" : 0 ]
]
@PointClass size(-8 -8 -8, 8 8 8) color(255 255 128) = light : "Dynamic light (UZDoom)" [
  light(integer) : "Radius" : 200
  _color(color1) : "Colour" : "1 0.9 0.7"
]
@PointClass base(Appear) size(-16 -16 0, 16 16 32) color(160 160 160) = doom_thing : "Any Doom thing by its number" [ doomednum(integer) : "Thing type number" : 0 ]
`;
for (const t of THINGS) {
  const hasModel = spriteModel(t.cls, t.spr), r = t.r, h = t.h;
  fgd += `@PointClass base(Appear) size(-${r} -${r} 0, ${r} ${r} ${h}) color(${colour(t.cls)})${hasModel ? ` model({ "path": "sprites/${t.cls}.obj" })` : ''} = ${t.cls} : "${t.name} (${t.type})" []\n`;
}
console.log(`things: ${THINGS.length}, ${ns} with sprites`);

// 4. game config, icon, starter map
fs.writeFileSync(path.join(gameDir, 'Doom.fgd'), fgd);
const icon = G.picture('STFST01') || G.sprite('SKULA');
if (icon) fs.writeFileSync(path.join(gameDir, 'Icon.png'), png(icon.w, icon.h, icon.rgba));
fs.writeFileSync(path.join(gameDir, 'GameConfig.cfg'), JSON.stringify({
  version: 9, name: 'Doom', icon: 'Icon.png',
  fileformats: [{ format: 'Valve', initialmap: 'initial_valve.map' }, { format: 'Standard' }],
  filesystem: { searchpath: 'doom', packageformat: { extension: '.pak', format: 'idpak' } },
  materials: { root: 'textures', extensions: ['.png'] },
  entities: { definitions: ['Doom.fgd'], defaultcolor: '0.6 0.6 0.6 1.0' },
  tags: {
    brush: [{ name: 'Sector volume', attribs: ['transparent'], match: 'classname', pattern: 'doom_sector' }],
    brushface: [{ name: 'Sky', match: 'material', pattern: 'flats/F_SKY1' }],
  },
  faceattribs: { surfaceflags: [], contentflags: [] },
  softMapBounds: '-32768 -32768 -16384 32768 32768 16384',
}, null, 2));
// starter map: a 512 x 512 room, 128 high, with a player start
function box(x0, y0, z0, x1, y1, z1, tex) {
  const T = tex || {}, face = (p, a, b, U, V, t) => `( ${p.join(' ')} ) ( ${p.map((v, i) => v + b[i]).join(' ')} ) ( ${p.map((v, i) => v + a[i]).join(' ')} ) ${t} [ ${U.join(' ')} 0 ] [ ${V.join(' ')} 0 ] 0 1 1`;
  const W = T.wall || 'walls/STARTAN2', F = T.top || 'flats/FLOOR4_8', C = T.bottom || 'flats/CEIL3_5';
  return ['{',
    face([x0, y0, z1], [1, 0, 0], [0, 1, 0], [1, 0, 0], [0, -1, 0], F), // top (+z)
    face([x0, y0, z0], [0, 1, 0], [1, 0, 0], [1, 0, 0], [0, -1, 0], C), // bottom (-z)
    face([x1, y0, z0], [0, 1, 0], [0, 0, 1], [0, 1, 0], [0, 0, -1], W), // +x
    face([x0, y0, z0], [0, 0, 1], [0, 1, 0], [0, -1, 0], [0, 0, -1], W), // -x
    face([x0, y1, z0], [0, 0, 1], [1, 0, 0], [-1, 0, 0], [0, 0, -1], W), // +y
    face([x0, y0, z0], [1, 0, 0], [0, 0, 1], [1, 0, 0], [0, 0, -1], W), // -y
    '}'].join('\n');
}
const room = (x0, y0, x1, y1, f, c, t = 16) => [box(x0 - t, y0 - t, f - t, x1 + t, y1 + t, f), box(x0 - t, y0 - t, c, x1 + t, y1 + t, c + t), box(x0 - t, y0 - t, f, x0, y1 + t, c), box(x1, y0 - t, f, x1 + t, y1 + t, c), box(x0, y0 - t, f, x1, y0, c), box(x0, y1, f, x1, y1 + t, c)];
const starter = `// Game: Doom\n// Format: Valve\n{\n"classname" "worldspawn"\n"mapversion" "220"\n"message" "My Level"\n"mapname" "MAP01"\n"sectorlight" "192"\n${room(-256, -256, 256, 256, 0, 128).join('\n')}\n}\n{\n"classname" "info_player_start"\n"origin" "0 -128 0"\n"angle" "90"\n}\n`;
fs.writeFileSync(path.join(gameDir, 'initial_valve.map'), starter);

// 5. compile profiles: build the WAD (and play it) straight from TrenchBroom's Run > Compile Map
const node = process.execPath, conv = fwd(path.join(KIT, 'map2wad.js'));
const buildDir = path.join(KIT, 'build'); fs.mkdirSync(buildDir, { recursive: true }); // works for unsaved maps too
const exp = '${WORK_DIR_PATH}/${MAP_BASE_NAME}-export.map', out = '${WORK_DIR_PATH}/${MAP_BASE_NAME}.wad';
const profile = (name, play) => ({ name, workdir: fwd(buildDir), tasks: [
  { type: 'export', enabled: true, target: exp },
  { type: 'tool', enabled: true, tool: fwd(node), parameters: `"${conv}" "${exp}" "${out}"${play ? ' --play' : ''}`, treatNonZeroResultCodeAsError: true },
] });
fs.writeFileSync(path.join(gameDir, 'CompilationProfiles.cfg'), JSON.stringify({ profiles: [profile('Build WAD and play in UZDoom', true), profile('Build WAD only', false)], version: 1 }, null, 4));
fs.writeFileSync(path.join(KIT, 'config.json'), JSON.stringify({ uzdoom: fwd(uzdoom), iwad: fwd(iwad), skill: 3 }, null, 2));
// 6. tell TrenchBroom where the game files are (only when it is closed: it rewrites its preferences on exit)
const prefFile = path.join(userData, 'Preferences.json');
let prefs = {}; try { prefs = JSON.parse(fs.readFileSync(prefFile, 'utf8')); } catch (e) { }
prefs['Games/Doom/Path'] = fwd(gamePath);
fs.writeFileSync(prefFile, JSON.stringify(prefs, null, 4));
console.log('TrenchBroom game installed in ' + gameDir);
console.log('Game path set to ' + gamePath);
console.log('\nDone. Open TrenchBroom, choose New map > Doom, and use Run > Compile Map to play.');
