@echo off
title TrenchBroom Doom Kit - install
cd /d "%~dp0"
echo TrenchBroom Doom Kit
echo ====================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Get the LTS version from https://nodejs.org , install it, then run Install.cmd again.
  pause & exit /b 1
)
tasklist | find /i "TrenchBroom.exe" >nul
if not errorlevel 1 (
  echo Please close TrenchBroom first, then run Install.cmd again.
  pause & exit /b 1
)
node setup.js
if errorlevel 2 goto ask
if errorlevel 1 goto failed
goto done

:ask
echo.
echo Could not find everything automatically. Paste the full paths below
echo (tip: Shift + right-click the file in Explorer and choose "Copy as path").
echo.
set /p ENGINE=Path to uzdoom.exe or gzdoom.exe:
set /p IWAD=Path to DOOM2.WAD:
set ENGINE=%ENGINE:"=%
set IWAD=%IWAD:"=%
node setup.js --uzdoom "%ENGINE%" --iwad "%IWAD%"
if errorlevel 1 goto failed
goto done

:failed
echo.
echo Setup did not finish. Check the paths above and run Install.cmd again.
pause & exit /b 1

:done
echo.
pause
