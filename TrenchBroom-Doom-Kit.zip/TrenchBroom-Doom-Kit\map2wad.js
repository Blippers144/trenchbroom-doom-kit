#!/usr/bin/env node
// TrenchBroom .map -> Doom WAD (UDMF, for UZDoom/GZDoom).
// Usage: node map2wad.js <in.map> [out.wad] [--play] [--map MAP01]
//
// How brushes become Doom sectors: the level is looked at from above and cut into pieces wherever a brush
// outline is. For each piece we look straight up through all the brushes: the top of the lowest solid is
// the sector floor, the bottom of the highest solid is the ceiling, and any solids in between become
// UZDoom 3D floors (bridges, platforms, overhangs). Sloped brush faces become sloped floors/ceilings.
'use strict';
const fs = require('fs'), path = require('path'), { spawn } = require('child_process');
const { parseMap, buildBrush, column, inside, uv, dot } = require('./lib/mapfile');
const { arrange, inRegion } = require('./lib/arrange');
const { writeWad } = require('./lib/wad');
const THINGS = require('./lib/things');

const DEF_WALL = 'STARTAN2', DEF_FLAT = 'FLOOR4_8', DEF_CEIL = 'CEIL3_5';
const texName = (t, def) => { if (!t || /^__TB_empty$/i.test(t) || t === 'NULL') return def; const n = t.split('/').pop().replace(/\^/g, '\\').toUpperCase(); return n.slice(0, 8) || def; };
const fmt = v => { const r = Math.round(v * 1000) / 1000; return Number.isInteger(r) ? String(r) : String(r); };
const SOLID_ENTS = /^(worldspawn|func_group|func_detail|func_wall|func_detail_wall)$/;

function convert(text, opts = {}) {
  const warn = [];
  const ents = parseMap(text), world = ents.find(e => e.props.classname === 'worldspawn') || { props: {}, brushes: [] };
  const mapName = (opts.map || world.props.mapname || 'MAP01').toUpperCase();
  const baseLight = +(world.props.sectorlight || world.props.light || 192);
  const solids = [], volumes = [];
  for (const e of ents) {
    const cls = e.props.classname || '';
    for (const b0 of e.brushes) {
      const b = buildBrush(b0); if (!b) { warn.push(`skipped a broken brush in ${cls}`); continue; }
      b.ent = e;
      if (cls === 'doom_sector') volumes.push(b); else if (SOLID_ENTS.test(cls) || !cls.startsWith('trigger')) solids.push(b);
    }
  }
  if (!solids.length) throw new Error('The map has no brushes.');
  // 1. outlines from above
  const segs = [];
  const addPoly = poly => { for (let i = 0; i < poly.length; i++) { const a = poly[i], b = poly[(i + 1) % poly.length]; segs.push([[a[0], a[1]], [b[0], b[1]]]); } };
  for (const b of solids) for (const f of b.faces) if (Math.abs(f.n[2]) > 1e-4) addPoly(f.poly);
  for (const b of volumes) for (const f of b.faces) if (f.n[2] > 1e-4) addPoly(f.poly);
  const A = arrange(segs);
  // 2. what each piece is
  const slabKeys = new Map(); // key -> {lo, hi, loF, hiF, side texture, tag}
  const planeKey = f => f.n.map(x => x.toFixed(5)).join(',') + ',' + f.d.toFixed(3);
  let nextTag = 1;
  for (const r of A.regions) {
    r.void = true; if (!r.point) continue;
    const [x, y] = r.point, cols = [];
    for (const b of solids) { const c = column(b, x, y); if (c) { c.brush = b; cols.push(c); } }
    cols.sort((p, q) => p.lo - q.lo);
    const merged = [];
    for (const c of cols) {
      const m = merged[merged.length - 1];
      if (m && c.lo <= m.hi + 0.01) { if (c.hi > m.hi) { m.hi = c.hi; m.hiF = c.hiF; } m.brushes.push(c.brush); }
      else merged.push({ lo: c.lo, hi: c.hi, loF: c.loF, hiF: c.hiF, brushes: [c.brush] });
    }
    if (merged.length < 2) continue;
    r.void = false;
    const F = merged[0], Cc = merged[merged.length - 1];
    r.floorF = F.hiF; r.floorZ = F.hi; r.ceilF = Cc.loF; r.ceilZ = Cc.lo;
    r.slabs = merged.slice(1, -1).map(s => {
      const k = planeKey(s.loF) + '/' + planeKey(s.hiF) + '/' + s.loF.tex + '/' + s.hiF.tex;
      let sl = slabKeys.get(k);
      if (!sl) { const side = s.brushes.map(b => b.faces.find(f => Math.abs(f.n[2]) < 0.01)).find(Boolean); sl = { k, loF: s.loF, hiF: s.hiF, lo: s.lo, hi: s.hi, side: side ? texName(side.tex, DEF_WALL) : DEF_WALL, tag: nextTag++, x, y }; slabKeys.set(k, sl); }
      return sl;
    });
    // sector properties from doom_sector volumes
    const P = [x, y, r.floorZ + 1], vol = volumes.find(v => inside(v, P, -1e-4)), vp = vol ? vol.ent.props : {};
    r.props = { light: vp.light !== undefined ? +vp.light : baseLight, special: +(vp.special || 0), color: vp.color || '', fade: vp.fade || '', tag: +(vp.tag || 0), secret: vp.secret === '1' };
    r.ftex = texName(r.floorF.tex, DEF_FLAT); r.ctex = texName(r.ceilF.tex, DEF_CEIL);
    r.key = [planeKey(r.floorF), planeKey(r.ceilF), r.ftex, r.ctex, JSON.stringify(r.props), r.slabs.map(s => s.tag).join(','), r.floorF.ou, r.floorF.ov, r.ceilF.ou, r.ceilF.ov].join('|');
  }
  // 3. join neighbouring pieces that look the same into one sector
  const parent = new Map(); const find = r => { while (parent.get(r) !== r) { parent.set(r, parent.get(parent.get(r))); r = parent.get(r); } return r; };
  for (const r of A.regions) parent.set(r, r);
  for (const e of A.edges) if (e.left && e.right && !e.left.void && !e.right.void && e.left.key === e.right.key) parent.set(find(e.left), find(e.right));
  const sectors = [], secOf = new Map();
  for (const r of A.regions) { if (r.void) continue; const root = find(r); let s = secOf.get(root); if (!s) { s = { r: root, idx: sectors.length }; sectors.push(s); secOf.set(root, s); } secOf.set(r, s); }
  const sec = r => r && !r.void ? secOf.get(r) : null;
  // 4. linedefs and sidedefs
  const verts = [], vIdx = new Map(), vert = v => { let i = vIdx.get(v); if (i === undefined) { i = verts.length; verts.push(v); vIdx.set(v, i); } return i; };
  const lines = [], sides = [];
  const zAt = (f, x, y) => (f.d - f.n[0] * x - f.n[1] * y) / f.n[2];
  function wallFace(mx, my, z, nx, ny) {
    // a vertical brush face lying on this line and facing the side we're texturing
    for (const b of solids) {
      if (mx < b.bb[0] - 0.1 || mx > b.bb[3] + 0.1 || my < b.bb[1] - 0.1 || my > b.bb[4] + 0.1 || z < b.bb[2] - 0.1 || z > b.bb[5] + 0.1) continue;
      for (const f of b.faces) {
        if (Math.abs(f.n[2]) > 0.02 || f.n[0] * nx + f.n[1] * ny < 0.7) continue;
        const p = [mx, my, z]; if (Math.abs(dot(f.n, p) - f.d) > 0.05) continue;
        if (b.faces.every(g => g === f || dot(g.n, p) <= g.d + 0.05)) return f;
      }
    }
    // fallback: whatever solid is just behind the line
    for (const b of solids) { const p = [mx - nx * 1, my - ny * 1, z]; if (inside(b, p, 0)) { let best = null, bd = Infinity; for (const f of b.faces) { if (Math.abs(f.n[2]) > 0.5) continue; const d = Math.abs(dot(f.n, p) - f.d); if (d < bd) { bd = d; best = f; } } if (best) return best; } }
    return null;
  }
  function texSide(S, O, a, b, line) {
    // S: sector on this side, O: other sector (or null). a->b runs the way Doom draws this side.
    const L = Math.hypot(b.x - a.x, b.y - a.y), dx = (b.x - a.x) / L, dy = (b.y - a.y) / L, nx = dy, ny = -dx; // normal pointing into S... (right of a->b)
    const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
    const sf = zAt(S.r.floorF, mx, my), sc = zAt(S.r.ceilF, mx, my);
    const side = { sector: S.idx, top: '-', mid: '-', bottom: '-', off: {} };
    const part = (name, z0, z1, anchor) => {
      const f = wallFace(mx, my, (z0 + z1) / 2, nx, ny);
      side[name] = f ? texName(f.tex, DEF_WALL) : DEF_WALL;
      if (f) {
        const p0 = [a.x, a.y, anchor], [u0, v0] = uv(f, p0);
        side.off[name] = [u0, v0];
        const sx = Math.abs((dx * f.U[0] + dy * f.U[1]) / f.su), sy = Math.abs(f.V[2] / f.sv);
        if (sx > 0.01 && Math.abs(sx - 1) > 0.001) side.off['sx_' + name] = sx;
        if (sy > 0.01 && Math.abs(sy - 1) > 0.001) side.off['sy_' + name] = sy;
      }
    };
    if (!O) part('mid', sf, sc, sc);
    else {
      const of = zAt(O.r.floorF, mx, my), oc = zAt(O.r.ceilF, mx, my);
      if (of > sf + 0.01) part('bottom', sf, of, of);
      if (oc < sc - 0.01 && !(S.r.ctex === 'F_SKY1' && O.r.ctex === 'F_SKY1')) { part('top', oc, sc, sc); line.dontpegtop = true; }
    }
    sides.push(side); return sides.length - 1;
  }
  for (const e of A.edges) {
    let sl = sec(e.left), sr = sec(e.right), a = e.a, b = e.b;
    if (sl === sr) continue;
    if (!sr) { [sl, sr] = [sr, sl]; [a, b] = [b, a]; } // the front (right) side must exist
    const line = { v1: vert(a), v2: vert(b) };
    line.front = texSide(sr, sl, a, b, line);
    if (sl) { line.back = texSide(sl, sr, b, a, line); line.twosided = true; } else line.blocking = true;
    lines.push(line);
  }
  // 5. 3D floor control sectors, placed in a row outside the map
  let maxX = -Infinity, minY = Infinity; for (const v of verts) { maxX = Math.max(maxX, v.x); minY = Math.min(minY, v.y); }
  const controls = [];
  [...slabKeys.values()].forEach((sl, i) => {
    const x0 = Math.ceil((maxX + 256) / 64) * 64 + i * 128, y0 = Math.floor(minY / 64) * 64, x1 = x0 + 64, y1 = y0 + 64;
    const csec = { control: sl, idx: sectors.length }; sectors.push(csec);
    const P = [{ x: x0, y: y0 }, { x: x0, y: y1 }, { x: x1, y: y1 }, { x: x1, y: y0 }].map(vert);
    for (let k = 0; k < 4; k++) { sides.push({ sector: csec.idx, top: '-', mid: sl.side, bottom: '-', off: {} }); const ln = { v1: P[k], v2: P[(k + 1) % 4], front: sides.length - 1, blocking: true }; if (k === 0) { ln.special = 160; ln.args = [sl.tag, 1, 0, 255]; } lines.push(ln); }
    controls.push(csec);
  });
  // 6. things
  const byCls = new Map(THINGS.map(t => [t.cls, t])), things = [];
  for (const e of ents) {
    const cls = e.props.classname || ''; if (!e.props.origin || e.brushes.length) continue;
    const [x, y, z] = e.props.origin.split(/\s+/).map(Number);
    let type = 0, args = null;
    if (cls === 'light') {
      type = 9800; const c = (e.props._color || e.props.color || '1 1 1').split(/\s+/).map(Number), k = c.some(v => v > 1) ? 1 : 255;
      args = [Math.round(c[0] * k) || 0, Math.round(c[1] * k) || 0, Math.round(c[2] * k) || 0, Math.round(+(e.props.light || e.props.radius || 200))];
    } else if (byCls.has(cls)) type = byCls.get(cls).type;
    else if (e.props.doomednum) type = +e.props.doomednum;
    else { if (cls !== 'worldspawn') warn.push(`ignored entity ${cls}`); continue; }
    const r = A.regions.find(q => !q.void && inRegion(q, x, y));
    if (!r && type !== 9800) warn.push(`${cls} at ${x} ${y} is outside the map`);
    const info = byCls.get(cls);
    const floor = r ? zAt(r.floorF, x, y) : 0, ceil = r ? zAt(r.ceilF, x, y) : 0;
    let height = info && info.hangs ? Math.max(0, ceil - z - info.h) : z - floor;
    if (cls === 'light') height = z - floor;
    let ang = e.props.angle !== undefined ? +e.props.angle : e.props.angles ? +e.props.angles.split(/\s+/)[1] : 0;
    const sf = +(e.props.spawnflags || 0);
    things.push({ type, x, y, height: Math.abs(height) < 0.5 ? 0 : Math.round(height), angle: ((Math.round(ang) % 360) + 360) % 360, args, ambush: !!(sf & 1), easy: !(sf & 2), med: !(sf & 4), hard: !(sf & 8), single: !(sf & 16), friend: !!(sf & 32), tid: +(e.props.tid || 0) });
  }
  if (!things.some(t => t.type === 1)) warn.push('No info_player_start: UZDoom will not be able to start the map.');
  // 7. UDMF text
  const out = ['namespace = "zdoom";', ''];
  const blk = (kind, kv) => { out.push(kind, '{'); for (const [k, v] of Object.entries(kv)) if (v !== undefined && v !== null && v !== false && v !== '') out.push(`${k} = ${typeof v === 'string' ? JSON.stringify(v) : v === true ? 'true' : fmt(v)};`); out.push('}', ''); };
  for (const t of things) blk('thing', { x: t.x, y: t.y, height: t.height || undefined, angle: t.angle, type: t.type, id: t.tid || undefined, skill1: t.easy, skill2: t.easy, skill3: t.med, skill4: t.hard, skill5: t.hard, single: t.single, coop: true, dm: true, ambush: t.ambush, friend: t.friend, arg0: t.args ? t.args[0] : undefined, arg1: t.args ? t.args[1] : undefined, arg2: t.args ? t.args[2] : undefined, arg3: t.args ? t.args[3] : undefined });
  for (const v of verts) blk('vertex', { x: v.x, y: v.y });
  for (const l of lines) blk('linedef', { v1: l.v1, v2: l.v2, sidefront: l.front, sideback: l.back, blocking: l.blocking, twosided: l.twosided, dontpegtop: l.dontpegtop, special: l.special, arg0: l.args ? l.args[0] : undefined, arg1: l.args ? l.args[1] : undefined, arg2: l.args ? l.args[2] : undefined, arg3: l.args ? l.args[3] : undefined });
  for (const s of sides) {
    const o = s.off, kv = { sector: s.sector, texturetop: s.top, texturebottom: s.bottom, texturemiddle: s.mid };
    for (const [p, n] of [['top', 'top'], ['mid', 'mid'], ['bottom', 'bottom']]) if (o[p]) { kv['offsetx_' + n] = Math.round(o[p][0] * 1000) / 1000 || undefined; kv['offsety_' + n] = Math.round(o[p][1] * 1000) / 1000 || undefined; if (o['sx_' + p]) kv['scalex_' + n] = o['sx_' + p]; if (o['sy_' + p]) kv['scaley_' + n] = o['sy_' + p]; }
    blk('sidedef', kv);
  }
  const planeKV = (kv, f, which) => { if (Math.abs(f.n[2]) > 0.99999) return; kv[which + 'plane_a'] = +f.n[0].toFixed(6); kv[which + 'plane_b'] = +f.n[1].toFixed(6); kv[which + 'plane_c'] = +f.n[2].toFixed(6); kv[which + 'plane_d'] = +(-f.d).toFixed(4); };
  for (const s of sectors) {
    if (s.control) {
      const sl = s.control, kv = { heightfloor: Math.round(zAt(sl.loF, sl.x, sl.y)), heightceiling: Math.round(zAt(sl.hiF, sl.x, sl.y)), texturefloor: texName(sl.loF.tex, DEF_FLAT), textureceiling: texName(sl.hiF.tex, DEF_FLAT), lightlevel: baseLight };
      planeKV(kv, sl.loF, 'floor'); planeKV(kv, sl.hiF, 'ceiling'); blk('sector', kv); continue;
    }
    const r = s.r, [x, y] = r.point, ids = [r.props.tag, ...r.slabs.map(q => q.tag)].filter(Boolean);
    const kv = { heightfloor: Math.round(zAt(r.floorF, x, y) * 1000) / 1000, heightceiling: Math.round(zAt(r.ceilF, x, y) * 1000) / 1000, texturefloor: r.ftex, textureceiling: r.ctex, lightlevel: Math.max(0, Math.min(255, r.props.light)), special: r.props.special || undefined, id: ids[0], moreids: ids.length > 1 ? ids.slice(1).join(' ') : undefined };
    if (r.floorF.ou) kv.xpanningfloor = Math.round(r.floorF.ou * 100) / 100; if (r.floorF.ov) kv.ypanningfloor = Math.round(r.floorF.ov * 100) / 100;
    if (r.ceilF.ou) kv.xpanningceiling = Math.round(r.ceilF.ou * 100) / 100; if (r.ceilF.ov) kv.ypanningceiling = Math.round(r.ceilF.ov * 100) / 100;
    if (r.props.color) kv.lightcolor = parseInt(r.props.color.replace('#', ''), 16);
    if (r.props.fade) kv.fadecolor = parseInt(r.props.fade.replace('#', ''), 16);
    if (r.props.secret) kv.secret = true;
    planeKV(kv, r.floorF, 'floor'); planeKV(kv, r.ceilF, 'ceiling');
    blk('sector', kv);
  }
  const textmap = out.join('\n');
  const title = world.props.message || path.basename(opts.name || 'map', '.map');
  const mapinfo = `map ${mapName} "${title.replace(/"/g, "'")}"\n{\n  sky1 = "${(world.props.sky || 'SKY1').toUpperCase()}"\n  next = "${world.props.nextmap || 'MAP02'}"\n}\n`;
  const wad = writeWad([['MAPINFO', mapinfo], [mapName, ''], ['TEXTMAP', textmap], ['ENDMAP', '']]);
  return { wad, textmap, mapName, warn, stats: { sectors: sectors.length - controls.length, lines: lines.length, things: things.length, floors3d: controls.length } };
}

function loadConfig() { try { return JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8')); } catch (e) { return {}; } }

if (require.main === module) {
  const argv = process.argv.slice(2), flags = new Set(argv.filter(a => a.startsWith('--'))), files = argv.filter((a, i) => !a.startsWith('--') && argv[i - 1] !== '--map');
  const mi = argv.indexOf('--map');
  if (!files[0]) { console.log('Usage: node map2wad.js <in.map> [out.wad] [--play] [--map MAP01]'); process.exit(1); }
  const inp = path.resolve(files[0]), outp = path.resolve(files[1] || inp.replace(/(-export)?\.map$/i, '') + '.wad');
  try {
    const t0 = Date.now(), r = convert(fs.readFileSync(inp, 'utf8'), { map: mi >= 0 ? argv[mi + 1] : null, name: inp.replace(/-export\.map$/i, '.map') });
    fs.writeFileSync(outp, r.wad);
    for (const w of r.warn) console.log('warning: ' + w);
    console.log(`${path.basename(outp)}: ${r.mapName}, ${r.stats.sectors} sectors, ${r.stats.lines} linedefs, ${r.stats.things} things, ${r.stats.floors3d} 3D floors (${Date.now() - t0} ms)`);
    if (flags.has('--play')) {
      const c = loadConfig();
      if (!c.uzdoom || !fs.existsSync(c.uzdoom)) throw new Error('UZDoom not found: run setup.js again');
      const child = spawn(c.uzdoom, ['-iwad', c.iwad, '-file', outp, '+map', r.mapName, '-skill', String(c.skill || 3)], { cwd: path.dirname(c.uzdoom), detached: true, stdio: 'ignore' });
      child.unref(); console.log('Started UZDoom');
    }
  } catch (e) { console.error('ERROR: ' + e.message); process.exit(1); }
}
module.exports = { convert };
